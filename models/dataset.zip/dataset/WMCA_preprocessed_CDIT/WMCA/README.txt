Wide Multi Channel Presentation Attack (WMCA) dataset
-----------------------------------------------------

documentation/
-> attack_illustration_files.csv & bonafide_illustration_files.csv: contains the list of files which can be used as illustration material for scientific papers / conferences. DO NOT PUBLISH/DISPLAY ANY OTHER DATA 

preprocessed-face-station_CDIT/
-> contains the Color, Depth, Infrared and Thermal preprocessed data

preprocessed-face-station_RGB/
-> contains the RGB preprocessed data

